package com.example;

import java.io.ObjectInputStream;
import java.security.MessageDigest;
import java.security.KeyPairGenerator;
import javax.crypto.Cipher;
import java.sql.Statement;

public class VulnerableApp {
    public void executeRiskOperations(Object input, String user, Statement stmt) throws Exception {
        // Gatillo 1 y 2: Criptografía obsoleta (Cosecha ahora, descifra después)
        MessageDigest md1 = MessageDigest.getInstance("SHA-1");
        MessageDigest md2 = MessageDigest.getInstance("MD5");

        // Gatillo 3: Llave RSA peligrosamente corta
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(1024);

        // Gatillo 4: Inyección SQL clásica por concatenación
        stmt.executeQuery("SELECT * FROM users WHERE name = '" + user + "'");

        // Gatillo 5: Deserialización destructiva de objetos
        ObjectInputStream ois = new ObjectInputStream((java.io.InputStream) input);
    }
}
